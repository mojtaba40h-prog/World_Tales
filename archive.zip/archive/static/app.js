
function toggleTheme(){
  var cur = localStorage.getItem('op_theme');
  var next = cur === 'dark' ? 'light' : (cur === 'light' ? null : 'dark');
  if(next) document.documentElement.setAttribute('data-theme', next);
  else document.documentElement.removeAttribute('data-theme');
  if(next) localStorage.setItem('op_theme', next); else localStorage.removeItem('op_theme');
}
(function(){
  var saved = localStorage.getItem('op_theme');
  if(saved) document.documentElement.setAttribute('data-theme', saved);
})();
function doSearch(q){
  var box = document.getElementById('searchResults');
  q = q.trim().toLowerCase();
  if(!q){ box.style.display='none'; box.innerHTML=''; return; }
  var groups = {'characters':'شخصيات','arcs':'أركات','fruits':'فواكه الشيطان','locations':'أماكن'};
  var html = '';
  var any = false;
  Object.keys(groups).forEach(function(key){
    var items = (window.SEARCH_INDEX[key]||[]).filter(function(it){
      return (it.name + ' ' + (it.en||'')).toLowerCase().indexOf(q) !== -1;
    }).slice(0,5);
    if(items.length){ any = true;
      html += '<div class="sr-group">' + groups[key] + '</div>';
      items.forEach(function(it){
        html += '<a class="sr-item" href="' + it.url + '">' + it.name + ' <span class="sub">' + (it.en||'') + '</span></a>';
      });
    }
  });
  box.innerHTML = any ? html : '<div class="sr-group">لا توجد نتائج</div>';
  box.style.display = 'block';
}
document.addEventListener('click', function(e){
  if(!e.target.closest('.search-box') && !e.target.closest('#searchResults')){
    var box = document.getElementById('searchResults');
    if(box){ box.style.display='none'; }
  }
});
