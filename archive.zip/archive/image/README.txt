# صور أرشيف ون بيس

ضع الصور هنا بالأسماء التالية:
- luffy.jpg
- zoro.jpg
- nami.jpg
- ... (اسم ملف الصورة = قيمة id في ملفات data/*.json)
- background.jpg ← خلفية الموقع

الامتدادات المدعومة للصور: .jpg ثم .webp ثم .png.
