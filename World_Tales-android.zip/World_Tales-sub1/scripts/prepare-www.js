// Copies only the web files needed by the app into ./www (Capacitor's webDir).
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const out = path.join(root, 'www');

const include = [
  'index.html', '404.html',
  'about', 'assets', 'category', 'collection', 'css',
  'explore', 'js', 'library', 'read', 'settings', 'story'
];

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

for (const name of include) {
  const src = path.join(root, name);
  if (!fs.existsSync(src)) {
    console.warn('skip (missing):', name);
    continue;
  }
  fs.cpSync(src, path.join(out, name), {
    recursive: true,
    filter: (p) => !p.endsWith('.gitkeep')
  });
}
console.log('www ready ->', out);
